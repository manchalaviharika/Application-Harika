import tkinter as tk
from tkinter import messagebox
import csv
import os

# Function to save data to CSV
def save_data():
    name = entry_name.get().strip()
    age = entry_age.get().strip()
    gender = gender_var.get()
    course = entry_course.get().strip()
    contact = entry_contact.get().strip()

    if not (name and age and gender and course and contact):
        messagebox.showwarning("Input Error", "Please fill all fields")
        return
    
    # Optional: Validate age is number
    if not age.isdigit():
        messagebox.showwarning("Input Error", "Age must be a number")
        return
    
    # Save to CSV file
    file_exists = os.path.isfile('student_data.csv')
    with open('student_data.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            # write header only if file not exists
            writer.writerow(["Name", "Age", "Gender", "Course", "Contact"])
        writer.writerow([name, age, gender, course, contact])

    messagebox.showinfo("Success", "Student data saved successfully!")

    # Clear fields after saving
    entry_name.delete(0, tk.END)
    entry_age.delete(0, tk.END)
    gender_var.set(None)
    entry_course.delete(0, tk.END)
    entry_contact.delete(0, tk.END)

# Tkinter GUI setup
root = tk.Tk()
root.title("Student Bio Data Maintenance")
root.geometry("400x350")

# Labels and Entry widgets
tk.Label(root, text="Name:").grid(row=0, column=0, padx=10, pady=5, sticky='w')
entry_name = tk.Entry(root, width=30)
entry_name.grid(row=0, column=1)

tk.Label(root, text="Age:").grid(row=1, column=0, padx=10, pady=5, sticky='w')
entry_age = tk.Entry(root, width=30)
entry_age.grid(row=1, column=1)

tk.Label(root, text="Gender:").grid(row=2, column=0, padx=10, pady=5, sticky='w')
gender_var = tk.StringVar()
tk.Radiobutton(root, text="Male", variable=gender_var, value="Male").grid(row=2, column=1, sticky='w')
tk.Radiobutton(root, text="Female", variable=gender_var, value="Female").grid(row=2, column=1, padx=70, sticky='w')

tk.Label(root, text="Course:").grid(row=3, column=0, padx=10, pady=5, sticky='w')
entry_course = tk.Entry(root, width=30)
entry_course.grid(row=3, column=1)

tk.Label(root, text="Contact No:").grid(row=4, column=0, padx=10, pady=5, sticky='w')
entry_contact = tk.Entry(root, width=30)
entry_contact.grid(row=4, column=1)

# Submit Button
submit_btn = tk.Button(root, text="Submit", command=save_data)
submit_btn.grid(row=5, column=1, pady=20)

root.mainloop()
