pip install <package_name>
